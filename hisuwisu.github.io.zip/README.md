# README 

## Adresse hisuwisu.github.io

### Sprachlerntagebuch

### Name , tm.ferdin!, 1981 , {{MITF}}

### README.html < shared_text.txt > markor < README.md

$ markor 
  - Einstellungen 
    - Ansicht Modus 
      - injektion > body 
        - append > header.pug
      - injektion > head
        - append > head.pug

Import School Referenzen

  - tryw3css_examples_magazine > save drive  > this.editor Upload File
  - tryw3css_examples_contact  > save drive  > this.editor Upload File

Include an HTML file:

  - <div w3-include-html="content.html"></div>
  - w3.includeHTML();
  - try With CSS save drive tryw3js_html_include_1_style > this.editor

> Ok Fred, How To Do , Homepage start index.html 
$ pug > index.html this.editor write
    title Index of Homepage
> check in 141714092020

append script
append link

next 

> <script src="w3.js"></script>
 
> <link rel="stylesheet" href="w3.css">

> ceck out 1423092020

> NOTE : Replace > tryw3css_examples_contact.html
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   tryw3css_examples_contact.html 
   Symbole HTML , bemutzen , Vermerk in README.md wenn erledigt
> check out 1445 
% <input class="w3-input w3-border" id="NAME" name="NAME" type="text" placeholder="Name">
% <input class="w3-input w3-border" id="AGE"  name="AGE"  type="text" placeholder="Age">
% github Log für wie was wer gemacht Sponsoren Openn Source Kommunizieren mit den die Inspiration , Zu diesem Projekt google kommt in dieser Geschichte aucj vor 
% hänge mich gerade auf , wohl gefühlt wie Bildungs es vorlegen oder Kurzschließen was Bedeutet Befehlssatz folgen  wir komma auf den punkt 
% Muss beides gehen Schablonem system anwender wHlt selber aus function tauscht Katalog Adresse ist Ergebnis Das Anwender es handhaben kann voller Funtions um gang mit dem Hand Gerät. Sehen und verstehen Multimedia Produkt Platzierung.von Sponsoren immer willkommen email tm.ferdim@gmail.com
% local host , ajax , json profil , drive 
% check out 1518
% tryw3css_examples_contact.html
% Drive set Vorlagen offline verfügbar , Eingestellt , TRUE
% tryw3css_templates_fifty = Homepage > homepage.pug